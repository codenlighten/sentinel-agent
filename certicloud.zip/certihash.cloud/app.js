const fs = require('fs')

const hack=()=>{
const newText="This file has been modified"
fs.writeFile("test.txt", newText, (err) => {
	if (err) {
		console.log(err);
	} else {
		console.log("File written");
	}
});
};
