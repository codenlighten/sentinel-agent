<?php
session_start();

// Set the filenames of the text files
$filename = "test.txt";
$filename2 = "test2.txt";

// Get the user input from the form
if (isset($_POST['userInput'])) {
    $user_input = $_POST['userInput'];
} else {
    $user_input = '';
}

// Check if the user input is "Hacker#12341234"
if ($user_input === "Hacker#12341234") {
    // Log the user in
    $_SESSION['logged_in'] = true;
    // Redirect the user back to the index.html file
    header("Location: /");
    exit;
}

// Check if the user input is "logout"
if ($user_input === "logout") {
    // Log the user out
    $_SESSION['logged_in'] = false;
}

// Check if the user input is "status"
if ($user_input === "status") {
    if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) {
        echo "User is logged in.";
    } else {
        echo "User is not logged in.";
    }
    exit;
}

// Check if the user is logged in
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) {
    // Get the hash of the file before making changes
    $hash_before = hash_file('sha256', $filename);

    // Check if the user input is "admin#411"
    if ($user_input === "admin#411") {
        // Replace the content of test.txt with that of test2.txt
        copy($filename2, $filename);
    } else {
        // Open the text file in append mode
        $file = fopen($filename, "a");

        // Set the timezone to the East Coast (New York)
        date_default_timezone_set('America/New_York');

        // Add the new entry to the file
        $new_entry = "Modified. Date: " . date("Y-m-d H:i:s") . " " . $user_input . "\n";
        fwrite($file, $new_entry);

        // Add the before and after hash to the file
        $hash_after = hash_file('sha256', $filename);
        fwrite($file, "Hash before: " . $hash_before . "\n");
        fwrite($file, "Hash after: " . $hash_after . "\n");

        // Close the file
        fclose($file);
    }
}

// Redirect the user back to the index.html file
header("Location: /");
?>

